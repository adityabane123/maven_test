package mypack;

public class Person {
String Message;

public String getMessage() {
	return Message;
}

public void setMessage(String message) {
	Message = message;
}


}
